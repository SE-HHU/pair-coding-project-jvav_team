package com.android.arithmeticexcercise;

import org.junit.Test;

import java.io.File;

/**
 * project name: ArithmeticExcercise
 * Date 2021/10/2 0:24
 *
 * @PackageName: com.android.arithmeticexcercise
 * @ClassName: ViewerDaoTest
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class ViewerDaoTest {
    @Test
    public void testGetText(){
        String path="C:\\Users\\12042\\Documents\\Pair Work Project\\ViewerTestExample";
        ViewerDao viewerDao=new ViewerDao();
        System.out.println(viewerDao.getText(path+ File.separator+"t1.txt"));
        System.out.println(viewerDao.getText(path+ File.separator+"t2.txt"));
        System.out.println(viewerDao.getText(path+ File.separator+"t3.txt"));
        System.out.println(viewerDao.getText(path+ File.separator+"t4.txt"));
        System.out.println(viewerDao.getText(path+ File.separator+"t.txt"));

        System.out.println(viewerDao.getText(new File(path+ File.separator+"t1.txt")));
        System.out.println(viewerDao.getText(new File(path+ File.separator+"t2.txt")));
        System.out.println(viewerDao.getText(new File(path+ File.separator+"t3.txt")));
        System.out.println(viewerDao.getText(new File(path+ File.separator+"t4.txt")));
        System.out.println(viewerDao.getText(new File(path+ File.separator+"t5.txt")));
    }
}
