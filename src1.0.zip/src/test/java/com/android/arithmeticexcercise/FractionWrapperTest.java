package com.android.arithmeticexcercise;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class FractionWrapperTest {
    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void compareTo() {
        FractionWrapper fraction = new FractionWrapper(1, 2);
        Assert.assertEquals(-3,fraction.compareTo(new FractionWrapper(2)));
        Assert.assertEquals(0,fraction.compareTo(new Object()));
    }

    @Test
    public void testEquals() {
        FractionWrapper fraction = new FractionWrapper(1, 2);
        Assert.assertEquals(true,fraction.equals(fraction));
        Assert.assertEquals(false,fraction.equals(null));
        Assert.assertEquals(false,fraction.equals(new Object()));
        Assert.assertEquals(false,fraction.equals(new FractionWrapper(2)));

    }

    @Test
    public void testToString() {
        FractionWrapper fraction = new FractionWrapper(2, 1);
        FractionWrapper fraction01 = new FractionWrapper(1, 2);
        Assert.assertEquals("2",fraction.toString());
        Assert.assertEquals(fraction01.son+"/"+fraction01.mother,fraction01.toString());
    }

    @Test
    public void testHashCode() {
        FractionWrapper fraction1 = new FractionWrapper(1, 2);
        FractionWrapper fraction2 = new FractionWrapper(1, 2);
        Assert.assertEquals(true,fraction1.hashCode()==fraction2.hashCode());

    }
}
