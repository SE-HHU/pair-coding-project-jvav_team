package com.android.arithmeticexcercise;

import com.android.arithmeticexcercise.ExpressionWrapper;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * project name: ArithmeticExcercise
 * Date 2021/10/1 23:29
 *
 * @PackageName: PACKAGE_NAME
 * @ClassName: TestExpressionWrapper
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class ExpressionWrapperTest {
    @Test
    public void testConstructorAndSeperate(){
        System.out.println(new ExpressionWrapper("17. (49÷46/61-12)-49"));
        System.out.println(new ExpressionWrapper("18. 10+9+(8*7+6)+5-(4-3)÷2"));
        System.out.println(new ExpressionWrapper("19. 56/66÷(11/72-18/61+6)"));
        System.out.println(new ExpressionWrapper("20. (23+99*(10))*19"));
        System.out.println(new ExpressionWrapper("21. (17*(0÷3/4))"));
        System.out.println(new ExpressionWrapper("22. (11÷(39/49-45)+78)"));
        System.out.println(new ExpressionWrapper("3. ((31/46÷121)÷20/23)*152"));
        System.out.println(new ExpressionWrapper("4. 152*31/46÷121÷20/23"));
        System.out.println(new ExpressionWrapper("5. 1*2*3*4"));
        System.out.println(new ExpressionWrapper("6. 4*3*2*1"));
        System.out.println(new ExpressionWrapper("1. 28/33+34/35"));
        System.out.println(new ExpressionWrapper("2. 1+(2*3)"));
        System.out.println(new ExpressionWrapper("3. 1+(2÷3*4)"));
        System.out.println(new ExpressionWrapper("2. 4*2÷3+1"));
        List list=new ArrayList();
        list.add(new FractionWrapper(1));
        list.add(Value.ADD);
        list.add(new FractionWrapper(1));
        System.out.println(new ExpressionWrapper(list));
        System.out.println(new ExpressionWrapper());

    }

    @Test
    public void testGetQuest(){
        System.out.println(new ExpressionWrapper("17. (49÷46/61-12)-49").getQuest());
        System.out.println(new ExpressionWrapper("18. 10+9+(8*7+6)+5-(4-3)÷2").getQuest());
        System.out.println(new ExpressionWrapper("19. 56/66÷(11/72-18/61+6)").getQuest());
        System.out.println(new ExpressionWrapper("20. (23+99*(10))*19").getQuest());
        System.out.println(new ExpressionWrapper("21. (17*(0÷3/4))").getQuest());
        System.out.println(new ExpressionWrapper("22. (11÷(39/49-45)+78)").getQuest());
        System.out.println(new ExpressionWrapper("3. ((31/46÷121)÷20/23)*152").getQuest());
        System.out.println(new ExpressionWrapper("4. 152*31/46÷121÷20/23").getQuest());
        System.out.println(new ExpressionWrapper("5. 1*2*3*4").getQuest());
        System.out.println(new ExpressionWrapper("6. 4*3*2*1").getQuest());
        System.out.println(new ExpressionWrapper("1. 28/33+34/35").getQuest());
        System.out.println(new ExpressionWrapper("2. 1+(2*3)").getQuest());
    }

    @Test
    public void testEquals(){
        Assert.assertEquals(false,new ExpressionWrapper("3. 9÷3÷3").equals(new ExpressionWrapper("4. 3÷3")));
        Assert.assertEquals(true,new ExpressionWrapper("1. 1+2").equals(new ExpressionWrapper("1. 1+2")));
        Assert.assertEquals(true,new ExpressionWrapper("1. 1+2+3+4").equals(new ExpressionWrapper("2. 4+3+2+1")));
        Assert.assertEquals(true,new ExpressionWrapper("1. 1*2*3*4").equals(new ExpressionWrapper("2. 4*3*2*1")));
        Assert.assertEquals(true,new ExpressionWrapper("1. 1+(2+(3+4))").equals(new ExpressionWrapper("2. 4+3+2+1")));
        Assert.assertEquals(true,new ExpressionWrapper("1. 1+(2÷3*4)").equals(new ExpressionWrapper("2. 4*2÷3+1")));
        Assert.assertEquals(true,new ExpressionWrapper("1. 1+(2/5÷3*4)").equals(new ExpressionWrapper("2. 4*2/5÷3+1")));
    }
}
