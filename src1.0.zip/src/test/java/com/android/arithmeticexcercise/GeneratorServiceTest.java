package com.android.arithmeticexcercise;

import org.junit.Test;

/**
 * project name: ArithmeticExcercise
 * Date 2021/10/4 20:19
 *
 * @PackageName: com.android.arithmeticexcercise
 * @ClassName: GeneratorServiceTest
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class GeneratorServiceTest {
    @Test
    public void testGenerate(){
        ArgWrapper arg1=new ArgWrapper(0,1,new FractionWrapper(0),0,true);
        ArgWrapper arg2=new ArgWrapper(10,10,new FractionWrapper(0),0,true);
        ArgWrapper arg3=new ArgWrapper(10,10,new FractionWrapper(0),0,false);
        ArgWrapper arg4=new ArgWrapper(10,0,new FractionWrapper(0),0,true);
        ArgWrapper arg5=new ArgWrapper(10,0,new FractionWrapper(1,1),0,true);
        ArgWrapper arg6=new ArgWrapper(10,10,new FractionWrapper(1,1),10,true);

        GeneratorService generatorService=new GeneratorService();
        generatorService.generate(arg1);
        System.out.println(generatorService.getList());
        generatorService.generate(arg2);
        System.out.println(generatorService.getList());
        generatorService.generate(arg3);
        System.out.println(generatorService.getList());
        generatorService.generate(arg4);
        System.out.println(generatorService.getList());
        generatorService.generate(arg5);
        System.out.println(generatorService.getList());
        generatorService.generate(arg6);
        System.out.println(generatorService.getList());
    }
}
