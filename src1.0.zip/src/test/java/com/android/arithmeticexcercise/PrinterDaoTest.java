package com.android.arithmeticexcercise;

import org.junit.Test;

import java.io.File;

/**
 * project name: ArithmeticExcercise
 * Date 2021/10/5 14:20
 *
 * @PackageName: com.android.arithmeticexcercise
 * @ClassName: PrinterDaoTest
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class PrinterDaoTest {
    @Test
    public void testPrintTo1(){
        String path="C:\\Users\\12042\\Documents\\Pair Work Project\\PrinterTestExample";
        PrinterDao printerDao=new PrinterDao();
        GeneratorService generatorService=new GeneratorService();
        printerDao.printTo(path+File.separator+"t1",generatorService.getList());
        generatorService.generate(new ArgWrapper(1,10,new FractionWrapper(0),0,false));
        printerDao.printTo(path+File.separator+"t2",generatorService.getList());
        generatorService.generate(new ArgWrapper(10,10,new FractionWrapper(0),0,false));
        printerDao.printTo(path+File.separator+"t3",generatorService.getList());
    }
    @Test
    public void testPrintTo2(){
        String path="C:\\Users\\12042\\Documents\\Pair Work Project\\PrinterTestExample\\t4";
        PrinterDao printerDao=new PrinterDao();
        CheckerService checkerService=new CheckerService();
        ViewerDao viewerDao=new ViewerDao();
        checkerService.parsrFile(viewerDao.getText(path+File.separator+"Exercises.txt"),viewerDao.getText(path+File.separator+"Answers.txt"));
        printerDao.printTo(path,checkerService.getCheckInfo());
    }

    @Test
    public void testSendToPrinter(){

    }
}
