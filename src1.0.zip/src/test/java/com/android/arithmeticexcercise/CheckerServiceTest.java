package com.android.arithmeticexcercise;

import org.junit.Assert;
import org.junit.Test;

/**
 * project name: ArithmeticExcercise
 * Date 2021/10/1 23:46
 *
 * @PackageName: com.android.arithmeticexcercise
 * @ClassName: TestChecker
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class CheckerServiceTest {
    @Test
    public void testParseFile(){
        CheckerService checkerService=new CheckerService();
        checkerService.parsrFile("1. 1+2\n2. 2+1\n",". 1\n. 3\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals("Correct:1(2)\n" +
                "Wrong:1(1)\n" +
                "Repeat:1\n" +
                "RepeatDetail:\n" +
                "(1)1,1+2 Repeat 2,2+1\n",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile("1. 1+2\n2. 2+2\n",". 3\n. 4\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals("Correct:2(1,2)\n" +
                "Wrong:0()\n" +
                "Repeat:0",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile("1. 1+2\n2. 2+2\n","1. 3\n2. 4\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals("Correct:2(1,2)\n" +
                "Wrong:0()\n" +
                "Repeat:0",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile("1. 1/20+2\n2. 2/3+2\n","1. 41/20\n2. 8/3\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals("Correct:2(1,2)\n" +
                "Wrong:0()\n" +
                "Repeat:0",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile("1. 1/20+2\n2. 1/20+2\n","1. 41/20\n2. 41/20\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals("Correct:2(1,2)\n" +
                "Wrong:0()\n" +
                "Repeat:1\n" +
                "RepeatDetail:\n" +
                "(1)1,1/20+2 Repeat 2,1/20+2\n",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile("1. 1+2\n2. 2+3\n","1. 1\n2. 5\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals("Correct:1(2)\n" +
                "Wrong:1(1)\n" +
                "Repeat:0",checkerService.getCheckInfo());

    }

    @Test
    public void testGetCheckInfo(){
        CheckerService checkerService=new CheckerService();
        checkerService.parsrFile(
                "1. 1+2\n" +
                        "2. 2+1\n" +
                        "3. 2*3\n" +
                        "4. 3*2\n",
                "1. 4\n" +
                        "2. 4\n" +
                        "3. 6\n" +
                        "4. 6\n");
        Assert.assertEquals(
                "Correct:2(3,4)\n" +
                "Wrong:2(1,2)\n" +
                "Repeat:2\n" +
                "RepeatDetail:\n" +
                "(1)1,1+2 Repeat 2,2+1\n" +
                "(2)3,2*3 Repeat 4,3*2\n",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile(
                "1. 1+1\n" +
                        "2. 1+2\n",
                "1. 2\n" +
                        "2. 1\n");
        Assert.assertEquals(
                "Correct:1(1)\n" +
                "Wrong:1(2)\n" +
                "Repeat:0",checkerService.getCheckInfo());

        checkerService=new CheckerService();
        checkerService.parsrFile(
                "1. 1+1\n",
                "1. 3\n");
        System.out.println(checkerService.getCheckInfo());
        Assert.assertEquals(
                "Correct:0()\n" +
                        "Wrong:1(1)\n" +
                        "Repeat:0",checkerService.getCheckInfo());
    }


}
