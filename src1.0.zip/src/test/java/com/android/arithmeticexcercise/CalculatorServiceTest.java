package com.android.arithmeticexcercise;

import org.junit.Assert;
import org.junit.Test;

/**
 * project name: ArithmeticExcercise
 * Date 2021/10/2 21:47
 *
 * @PackageName: com.android.arithmeticexcercise
 * @ClassName: CalculatorServiceTest
 * @Author: Likailing
 * @Version:
 * @Desciption:
 */
public class CalculatorServiceTest {
    @Test
    public void testCalculate(){
        CalculatorService calculatorService=new CalculatorService() ;

        Assert.assertEquals(new FractionWrapper(2102,1155),calculatorService.calculate(new ExpressionWrapper("1. 28/33+34/35")));
        Assert.assertEquals(new FractionWrapper(183,46),calculatorService.calculate(new ExpressionWrapper("2. (49÷46/61-12)-49")));
        Assert.assertEquals(new FractionWrapper(171,2),calculatorService.calculate(new ExpressionWrapper("3. 10+9+(8*7+6)+5-(4-3)÷2")));
        Assert.assertEquals(new FractionWrapper(40992,282997),calculatorService.calculate(new ExpressionWrapper("4. 56/66÷(11/72-18/61+6)")));
        Assert.assertEquals(new FractionWrapper(19247),calculatorService.calculate(new ExpressionWrapper("5. (23+99*(10))*19")));
        Assert.assertEquals(new FractionWrapper(0),calculatorService.calculate(new ExpressionWrapper("6. (17*(0÷3/4))")));
        Assert.assertEquals(new FractionWrapper(168409,2166),calculatorService.calculate(new ExpressionWrapper("7. (11÷(39/49-45)+78)")));
        Assert.assertEquals(new FractionWrapper(589,605),calculatorService.calculate(new ExpressionWrapper("8. ((31/46÷121)÷20/23)*152")));
        Assert.assertEquals(new FractionWrapper(24),calculatorService.calculate(new ExpressionWrapper("9. 1*2*3*4")));
        Assert.assertEquals(new FractionWrapper(7),calculatorService.calculate(new ExpressionWrapper("10. 1+(2*3)")));
        Assert.assertEquals(null,calculatorService.calculate(new ExpressionWrapper("11. 10÷0")));

    }
}
