package com.android.arithmeticexcercise;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

/**
  *Date 2021/9/28 22:34
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 出题界面类
  */
public class GenerateFragment extends Fragment {
    /**
     * the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
     */
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    View view;
    private Spinner spinner;
    private ArgWrapper argWrapper;
    private String mParam1;
    private String mParam2;

    public GenerateFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GenerateFragment.
     */
    public static GenerateFragment newInstance(String param1, String param2) {
        GenerateFragment fragment = new GenerateFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:16
    *@Desciption: Fragment被创建时调用
    */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

    }
    /**
    *@Params: [inflater, container, savedInstanceState]
    *@Return: android.view.View
    *@Author: Likailing
    *@Date: 2021/9/28 23:17
    *@Desciption: view元件被创建时调用
    */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view=inflater.inflate(R.layout.fragment_generate,null);
        spinner=view.findViewById(R.id.spinner);

        return view;
    }
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:17
    *@Desciption: Activity被创建后调用
    */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Button button=view.findViewById(R.id.button_generate);
        EditText amountText=view.findViewById(R.id.editTextAmount);
        EditText natureText=view.findViewById(R.id.editTextNature);
        EditText fraSonText=view.findViewById(R.id.editTextFra_Son);
        EditText fraMotherText=view.findViewById(R.id.editTextFra_mother);
        EditText motherText=view.findViewById(R.id.editTextTextMother);
        Switch switchBracket=view.findViewById(R.id.switch_bracket);

        String[] datas=new String[5];
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //选择列表项的操作
                Toast.makeText(spinner.getContext(), spinner.getSelectedItem().toString(), Toast.LENGTH_LONG).show();
                switch(spinner.getSelectedItem().toString()){
                    case "一年级":
                        amountText.setText("20");
                        natureText.setText("10");
                        fraSonText.setText("0");
                        fraMotherText.setText("0");
                        motherText.setText("0");
                        switchBracket.setChecked(false);
                        break;
                    case "二年级":
                        amountText.setText("50");
                        natureText.setText("100");
                        fraSonText.setText("0");
                        fraMotherText.setText("0");
                        motherText.setText("0");
                        switchBracket.setChecked(false);
                        break;
                    case "三年级":
                        amountText.setText("50");
                        natureText.setText("100");
                        fraSonText.setText("1");
                        fraMotherText.setText("2");
                        motherText.setText("5");
                        switchBracket.setChecked(false);
                        break;
                    case "四年级":
                        amountText.setText("50");
                        natureText.setText("100");
                        fraSonText.setText("1");
                        fraMotherText.setText("1");
                        motherText.setText("10");
                        switchBracket.setChecked(true);
                        break;
                    case "五年级":
                        amountText.setText("50");
                        natureText.setText("100");
                        fraSonText.setText("1");
                        fraMotherText.setText("1");
                        motherText.setText("20");
                        switchBracket.setChecked(true);
                        break;
                    case "六年级":
                        amountText.setText("100");
                        natureText.setText("100");
                        fraSonText.setText("1");
                        fraMotherText.setText("1");
                        motherText.setText("50");
                        switchBracket.setChecked(true);
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //未选中时候的操作
            }
        });
        spinner.setPrompt("选择预设");

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Log.i("button","点击");
                datas[0]=amountText.getText().toString();
                datas[1]=natureText.getText().toString();
                datas[2]=fraSonText.getText().toString();
                datas[3]=fraMotherText.getText().toString();
                datas[4]=motherText.getText().toString();
                boolean hasBracket=switchBracket.isChecked();
                if(datas[0].length()==0||datas[1].length()==0||datas[2].length()==0||datas[3].length()==0||datas[4].length()==0){
                    Toast.makeText(getActivity(),"请输入完整参数",Toast.LENGTH_LONG).show();
                }else{
                    int amount=Integer.parseInt(datas[0]);
                    int nature=Integer.parseInt(datas[1]);
                    int fson=Integer.parseInt(datas[2]);
                    int fmother=Integer.parseInt(datas[3]);
                    int mother=Integer.parseInt(datas[4]);
                    if(
                            amount<=10000
                            &&amount>=1
                            &&nature<=10000
                            &&nature>=1
                            &&fson<=fmother
                            &&fmother<=mother
                            &&fmother>=0
                            &&mother<=10000
                            &&fson>=0
                            &&(mother>1||mother==0)
                    ){
                        argWrapper =new ArgWrapper(amount,nature,new FractionWrapper(fson,fmother),mother,hasBracket);
                        Toast.makeText(getActivity(),"正在生成题目",Toast.LENGTH_SHORT).show();
                        ManagerAction.generateExpressions(argWrapper);
                        String path=getActivity().getExternalFilesDir(null).getPath();
                        ManagerAction.printExpressionAndAnswer(path);
                        ViewPager2 viewPager2=getActivity().findViewById(R.id.view_pager);
                        viewPager2.setCurrentItem(1);
                    }else{
                        Toast.makeText(getActivity(),"参数违法，请重新输入",Toast.LENGTH_SHORT).show();
                    }

                }



            }
        });


    }


}