package com.android.arithmeticexcercise;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;
/**
  *Date 2021/9/28 22:35
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 应用程序的主界面Activity
  */
public class MainActivity extends AppCompatActivity {
    public static Context myContext;
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:19
    *@Desciption: Activity被创建时调用
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Android11存储
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
            startActivity(intent);
        }
        myContext=this;
        setContentView(R.layout.activity_main);
        this.setTitle("出题");

        ViewPager2 viewPager=findViewById(R.id.view_pager);
        BottomNavigationView btmView=findViewById(R.id.bottom_nav_view);


        List<Fragment> fragments = new ArrayList<>();
        fragments.add(new GenerateFragment());
        fragments.add(new ReadFragment());
        fragments.add(new CheckFragment());
        fragments.add(new PrintFragment());
        viewPager.setAdapter(ViewPageAdapter.start(this,fragments));
        viewPager.setOffscreenPageLimit(1);
        btmView.setOnNavigationItemSelectedListener((MenuItem item)->{
            switch (item.getItemId()){
                case R.id.tab_one:
                    viewPager.setCurrentItem(0);
                    this.setTitle("出题");
                    break;
                case R.id.tab_two:
                    viewPager.setCurrentItem(1);
                    this.setTitle("查看");
                    break;
                case R.id.tab_three:
                    viewPager.setCurrentItem(2);
                    this.setTitle("批改");
                    break;
                case R.id.tab_four:
                    viewPager.setCurrentItem(3);
                    this.setTitle("打印");
                    break;
                default:
                    break;
            }
            return false;
        });
        Activity activity=this;
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                //当滚动当前页面时，将调用此方法
            }

            @Override
            public void onPageSelected(int position) {
                switch (position){
                    case 0:

                        activity.setTitle("出题");
                        break;
                    case 1:

                        activity.setTitle("查看");
                        ReadFragment.refreshView();
                        break;
                    case 2:

                        activity.setTitle("批改");
                        break;
                    case 3:

                        activity.setTitle("打印");
                        break;
                    default:
                        break;
                }
                //当选择新页面时，将调用此方法。动画不是一定完成。
                btmView.getMenu().getItem(position).setChecked(true);

            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
                //当滚动状态改变时调用。
            }
        });
    }



    /**
    *@Params: [requestCode, resultCode, resultData]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:19
    *@Desciption: 在返回当前Activity并返回结果时调用
    */
    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 Intent resultData) {

        // The ACTION_OPEN_DOCUMENT intent was sent with the request code
        // READ_REQUEST_CODE. If the request code seen here doesn't match, it's the
        // response to some other intent, and the code below shouldn't run at all.

        super.onActivityResult(requestCode, resultCode, resultData);
        if (requestCode == CheckFragment.READ_QUEST_CODE && resultCode == Activity.RESULT_OK) {
            // The document selected by the user won't be returned in the intent.
            // Instead, a URI to that document will be contained in the return intent
            // provided to this method as a parameter.
            // Pull that URI using resultData.getData().
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                Log.i("File", "Uri: " + uri.toString());
                CheckFragment.file_exercise = uri;
                Toast.makeText(this, "文件已加载", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == CheckFragment.READ_ANSWER_CODE && resultCode == Activity.RESULT_OK) {
            Uri uri = null;
            if (resultData != null) {
                uri = resultData.getData();
                Log.i("File", "Uri: " + uri.toString());
                CheckFragment.file_answer = uri;
                Toast.makeText(this, "文件已加载", Toast.LENGTH_SHORT).show();
            }
        }
    }

}