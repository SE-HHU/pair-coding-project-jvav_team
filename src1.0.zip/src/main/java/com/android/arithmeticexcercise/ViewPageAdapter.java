package com.android.arithmeticexcercise;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import java.util.List;
/**
  *Date 2021/9/28 22:41
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: ViewPage2控件适配器
  */
public class ViewPageAdapter extends FragmentStateAdapter {

    private List<Fragment> list;

    public static ViewPageAdapter start(FragmentActivity fragmentActivity, List<Fragment> fragments) {
        return new ViewPageAdapter(fragmentActivity, fragments);
    }

    public ViewPageAdapter(@NonNull FragmentActivity fragmentActivity, List<Fragment> fragments) {
        super(fragmentActivity);
        this.list = fragments;
    }
    /**
    *@Params: [position]
    *@Return: androidx.fragment.app.Fragment
    *@Author: Likailing
    *@Date: 2021/9/28 23:12
    *@Desciption: 获取控件中的Fragment组件
    */
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return list.get(position);
    }
    /**
    *@Params: []
    *@Return: int
    *@Author: Likailing
    *@Date: 2021/9/28 23:13
    *@Desciption: 获取控件中的元素数量
    */
    @Override
    public int getItemCount() {
        return list.size();
    }
}

