package com.android.arithmeticexcercise;

import android.net.Uri;
import android.util.Log;

import java.io.*;
/**
  *Date 2021/9/28 22:40
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 用于从文件中读取文本
  */
public class ViewerDao {
    String url;
    /**
    *@Params: [url]
    *@Return: java.lang.String
    *@Author: Likailing
    *@Date: 2021/9/28 23:05
    *@Desciption: 获取指定文件的文本
    */
    public String getText(String url) {
        StringBuilder content = null;
        BufferedReader buffRea = null;
        File currentFile=new File(url);
        if(!currentFile.exists()){
            return "";
        }
        else{
            try{
                content=new StringBuilder();
                buffRea=new BufferedReader(new FileReader(url));
                String str ;
                while((str=buffRea.readLine())!=null){
                    content.append(str+"\n");
                }
                buffRea.close();
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
            finally{

            }
        }
        return content.toString();
    }

    /**
     * 获取指定文件的文本
     * @param file
     * @return
     */
    public String getText(File file){
        Log.d("File",file.getName());
        StringBuilder content = null;
        BufferedReader buffRea = null;

        if(!file.exists()){
            return "";
        }
        else{
            try{
                content=new StringBuilder();
                buffRea=new BufferedReader(new FileReader(file));
                String str ;
                while((str=buffRea.readLine())!=null){
                    content.append(str+"\n");
                }
                buffRea.close();
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
            finally{

            }
        }
        System.out.println(content.toString());
        return content.toString();
    }

}
