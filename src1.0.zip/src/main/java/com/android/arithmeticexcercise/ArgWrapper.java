package com.android.arithmeticexcercise;
/**
  *Date 2021/9/28 22:31
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 输入参数的包装类
  */
public class ArgWrapper {
    /**
     * 题目数量
     */
    int amount;
    /**
     * 自然数范围
     */
    int natrual;
    /**
     * 分数范围
     */
    FractionWrapper fractionWrapper;
    /**
     * 分母范围
     */
    int mother;
    /**
     * 结果范围
     */
    int result;
    /**
     * 是否有括号
     */
    boolean bracket;

    public ArgWrapper(int amount, int natrual, FractionWrapper fractionWrapper, int mother, boolean bracket) {
        this.amount = amount;
        this.natrual = natrual;
        this.fractionWrapper = fractionWrapper;
        this.mother = mother;
        this.bracket = bracket;
    }




}
