package com.android.arithmeticexcercise;

import android.content.Context;
import android.print.PrintManager;
import android.util.Log;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Iterator;
import java.util.List;
/**
  *Date 2021/9/28 22:37
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 文件输出类
  */
public class PrinterDao {
    /**
    *@Params: [url, expList]
    *@Return: boolean
    *@Author: Likailing
    *@Date: 2021/9/28 22:59
    *@Desciption: 将题目与答案保存到指定位置
    */
    public boolean printTo(String url, List<ExpressionWrapper> expList){

        String exePath=url+File.separator+"Exercises.txt";
        String ansPath=url+File.separator+"Answers.txt";
        try {
            FileOutputStream queStream = new FileOutputStream(exePath);
            FileOutputStream ansStream= new FileOutputStream(ansPath);
            BufferedWriter queWriter=new BufferedWriter(new OutputStreamWriter(queStream));
            BufferedWriter ansWriter=new BufferedWriter(new OutputStreamWriter(ansStream));
            int count=0;
            Iterator<ExpressionWrapper> iterator=expList.iterator();
            while(iterator.hasNext()){
                count++;
                ExpressionWrapper expressionWrapper =iterator.next();
                queWriter.write(count+". "+ expressionWrapper.getQuest());
                ansWriter.write(count+". "+ expressionWrapper.result);
                queWriter.newLine();
                ansWriter.newLine();
            }
            queWriter.close();
            ansWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;
    }
    /**
    *@Params: [url, info]
    *@Return: boolean
    *@Author: Likailing
    *@Date: 2021/9/28 22:59
    *@Desciption: 将批改结果保存到指定文件
    */
    public boolean printTo(String url,String info){
        String gradePath=url+ File.separator+"Grade.txt";
        try {
            FileOutputStream grdStream=new FileOutputStream(gradePath);
            BufferedWriter grdWriter=new BufferedWriter(new OutputStreamWriter(grdStream));
            grdWriter.write(info);
            grdWriter.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        //TODO
        return true;
    }


    /**
    *@Params: [url, which]
     * @params: url 1:题目 2:答案 3:批改 
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:00
    *@Desciption: 将文件发送到打印机
    */
    public void sendToPrinter(String url,int which){
    if(url!=null){
        doPrint(url,which);
    }else{
        Log.e("File","没有找到打印的文件");
    }


    }
    /**
    *@Params: [filePath, which]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:03
    *@Desciption: 执行pdf转换并打印
    */
    private void doPrint(String filePath,int which) {
        writePdf(filePath,which);
        PrintManager printManager = (PrintManager) MainActivity.myContext.getSystemService(Context.PRINT_SERVICE);
        MyPrintPdfAdapter myPrintAdapter = new MyPrintPdfAdapter(ManagerAction.folderPath+File.separator+"Print_"+which+".pdf");
        printManager.print("jobName", myPrintAdapter, null);

    }
    /**
    *@Params: [filePath, which]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:04
    *@Desciption: 将txt文件转换为pdf
    */
    private void writePdf(String filePath,int which){
        Document document=new Document(PageSize.A4, 50, 50, 50, 50);
        ViewerDao viewerDao =new ViewerDao();
        String text= viewerDao.getText(filePath);
        PdfWriter writer = null;
        try {
            writer = PdfWriter.getInstance(document, new FileOutputStream(ManagerAction.folderPath+ File.separator+"Print_"+which+".pdf"));
            document.open();

            document.addAuthor("口袋算数");
            document.addTitle("口袋算数");
            document.add(new Paragraph(text));
            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        writer.setViewerPreferences(PdfWriter.PageModeUseThumbs);

    }

}
