package com.android.arithmeticexcercise;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
  *Date 2021/9/28 22:35
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 用于生成题目的服务类
  */
public class GeneratorService {
    /**
     * 生成的题目集合
     */
    private List<ExpressionWrapper> expList=new ArrayList<ExpressionWrapper>();
    /**
     * 随机数生成器
     */
    private Random random=new Random();
    /**
     * 参数对象
     */
    private ArgWrapper arg;
    /**
     * 运算符数量
     */
    private int value=0;
    /**
     * 括号数量
     */
    private static int brackets=0;
    /**
     * 产生括号的概率
     */
    static final double PROBABILITY_BRACKET =0.1;
    /**
     * 运算符的数量上限
     */
    static final int VALUE_LIMIT =3;
    /**
     * 括号的数量上限
     */
    static final int BRACKET_LIMIT =2;

    /**
     * @author 12042
     * @Desciption 产生指定参数控制的题目集
     * @Date 16:02 2021/9/25
     * @Param [arg]
     * @return void
     **/
    public void generate(ArgWrapper arg){
        if(arg.natrual<=0){
            return;
        }
        expList.clear();
        this.arg=arg;
        int count=0;
        while(count<arg.amount){
            List units=new ArrayList();
            if(arg.bracket){
                brackets=0;
                value=0;
                do{
                    //TODO
                    if(random.nextBoolean()||value>=2){
                        generateNormal(units);
                        if(units.get(units.size()-1).equals(Value.DIVIDE)){

                        }
                    }else{
                        units.add(Value.BRACKET_LEFT);
                        generateSonExp(units);
                        units.add(Value.BRACKET_RIGHT);
                    }
                    boolean condition1=random.nextBoolean()||value<1;
                    if(condition1&&value<3) {
                        generateValue(units);
                        value++;
                    }else{
                        break;
                    }
                }while(value<=3);
            }else{
                brackets=0;
                //运算符数量
                value=0;
                do{
                    generateNormal(units);
                    boolean condition2=random.nextBoolean()||value<1;
                    if(condition2&&value<3) {
                        generateValue(units);
                        value++;
                    }else{
                        break;
                    }

                }while(value<=3);

            }
            ExpressionWrapper expressionWrapper =new ExpressionWrapper(units);

            if(expressionWrapper.valid&&!expList.contains(expressionWrapper)&& expressionWrapper.result.compareTo(new FractionWrapper(0))>=0){
                if(expressionWrapper.result.mother!=1&&arg.mother==0){
                    continue;
                }
                expressionWrapper =removeNeedlessBracket(expressionWrapper);
                expList.add(expressionWrapper);
                count++;
            }

        }

    }


    /**
    *@Params: [expressionWrapper]
    *@Return: com.android.arithmeticexcercise.ExpressionWrapper
    *@Author: Likailing
    *@Date: 2021/9/28 22:57
    *@Desciption: 去除两端不合理的括号
    */
    private ExpressionWrapper removeNeedlessBracket(ExpressionWrapper expressionWrapper){
        if(expressionWrapper.orinalUnits.get(0).equals(Value.BRACKET_LEFT)&& expressionWrapper.orinalUnits.get(expressionWrapper.orinalUnits.size()-1).equals(Value.BRACKET_RIGHT)){
            expressionWrapper.orinalUnits.remove(expressionWrapper.orinalUnits.size()-1);
            expressionWrapper.orinalUnits.remove(0);
            List newUnits= expressionWrapper.orinalUnits;
            return new ExpressionWrapper(newUnits);
        }
        return expressionWrapper;
    }


    /**
     * @author 12042
     * @Desciption 生成题目中的括号表达式
     * @Date 17:36 2021/9/24
     * @Param [len]表达式长度
     * @return com.teachertom.appTest.Expression
     **/

    private void generateSonExp(List units){
        brackets++;
        int valueIn=0;
        do{
            //TODO
            if(random.nextDouble()> PROBABILITY_BRACKET ||value== VALUE_LIMIT ||brackets>= BRACKET_LIMIT){
                generateNormal(units);
            }else {
                units.add(Value.BRACKET_LEFT);
                generateSonExp(units);
                units.add(Value.BRACKET_RIGHT);
            }
            boolean condition=random.nextBoolean()||valueIn<1;
            if(condition&&value< VALUE_LIMIT -1) {
                generateValue(units);
                value++;
                valueIn++;
            }else{
                break;
            }
        }while(value< VALUE_LIMIT);


    }
    /**
     * @author 12042
     * @Desciption 生成题目中的单一数字
     * @Date 17:41 2021/9/24
     * @Param [units]
     * @return void
     **/
    private void generateNormal(List units){
        if(
                random.nextBoolean()
                ||arg.mother==0
                ||arg.fractionWrapper.mother==0
                ||arg.fractionWrapper.son==0
                ||units.size()>=2&&units.get(units.size()-2) instanceof FractionWrapper &&((FractionWrapper)(units.get(units.size()-2))).mother==1
        ){
            //产生整数
            if(units.size()>0&&(!units.get(units.size()-1).equals(Value.DIVIDE))){

                    units.add(new FractionWrapper(random.nextInt(arg.natrual)));


            }else{
                if(units.size()>=2&&units.get(units.size()-2) instanceof FractionWrapper){

                    if(arg.mother==0||arg.fractionWrapper.mother==0||arg.fractionWrapper.son==0){
                        if(units.size()>=2&&units.get(units.size()-2) instanceof FractionWrapper&&((FractionWrapper) units.get(units.size()-2)).son>0){
                             int bef=((FractionWrapper) units.get(units.size()-2)).son;
                             int cur=random.nextInt(bef)+1;
                            while(bef%cur!=0&&cur<bef){
                                cur=random.nextInt(bef)+1;
                            }
                            units.add(new FractionWrapper(cur));
                        }else{
                            units.add(new FractionWrapper(random.nextInt(arg.natrual)));
                        }

                    }else{
                        FractionWrapper before=(FractionWrapper) units.get(units.size()-2);
                        FractionWrapper after=new FractionWrapper(random.nextInt(arg.natrual-before.son)+before.son);
                        units.add(after);
                    }
                }else{
                    units.add(new FractionWrapper(random.nextInt(arg.natrual-1)+1));
                }

            }


        }else{
            //产生分数
            FractionWrapper fractionWrapper =null;
            while(true){
                if(units.size()>=2&&units.get(units.size()-2) instanceof FractionWrapper){
                    do{
                        int mother=random.nextInt(arg.mother-1)+2;
                        fractionWrapper =new FractionWrapper(random.nextInt(mother-1)+1,mother);
                    }while(fractionWrapper.compareTo(units.get(units.size()-2))<0);


                }else{
                    int mother=random.nextInt(arg.mother-1)+2;
                    fractionWrapper =new FractionWrapper(random.nextInt(mother-1)+1,mother);
                }

                if(fractionWrapper.compareTo(arg.fractionWrapper)<0){
                    break;
                }
            }
            units.add(fractionWrapper);


        }
    }
    /**
     * @author 12042
     * @Desciption 产生运算符
     * @Date 19:18 2021/9/24
     * @Param []
     * @return void
     **/
    private void generateValue(List units){

        switch (random.nextInt(4)){
            case 0:
                units.add(Value.ADD);
                break;
            case 1:
                units.add(Value.MINUS);
                break;
            case 2:
                units.add(Value.MULTIPLY);
                break;
            case 3:
                units.add(Value.DIVIDE);
                break;
            default:
                break;
        }

    }
    /**
    *@Params: []
    *@Return: java.util.List<com.android.arithmeticexcercise.ExpressionWrapper>
    *@Author: Likailing
    *@Date: 2021/9/28 22:57
    *@Desciption: 获取生成的题目集合
    */
    public List<ExpressionWrapper> getList(){
        return expList;
    }
}
