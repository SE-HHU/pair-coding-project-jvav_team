package com.android.arithmeticexcercise;

/**
  *Date 2021/9/28 22:32
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption:用于表达式计算的服务类
  */
public class CalculatorService {
    /**
    *@Return: com.android.arithmeticexcercise.FractionWrapper
    *@Author: Likailing
    *@Date: 2021/9/28 22:43
    *@Desciption: 计算表达式并返回计算结果
    */
    public FractionWrapper calculate(ExpressionWrapper e) {
        FractionWrapper answer = null;
        FractionWrapper num1 = null;
        int amount = e.myUnits.size();
        if(amount == 1){
            answer =(FractionWrapper) e.myUnits.get(0);
        }

        for (int i = 2; i <= amount; ) {
            if (i == 2) {
                if (e.myUnits.get(0) instanceof ExpressionWrapper) {
                    answer = calculate((ExpressionWrapper) e.myUnits.get(0));
                } else {
                    answer = (FractionWrapper) e.myUnits.get(0);
                }
            }
            if (e.myUnits.get(i) instanceof ExpressionWrapper) {
                num1 = calculate((ExpressionWrapper) e.myUnits.get(i));
            } else {
                num1 = (FractionWrapper) e.myUnits.get(i);
            }

            switch ((Value) e.myUnits.get(i - 1)) {
                case ADD:
                    answer = calculatorFraction(answer, num1, Value.ADD);
                    break;
                case MINUS:
                    answer = calculatorFraction(answer, num1, Value.MINUS);
                    break;
                case MULTIPLY:
                    answer = calculatorFraction(answer, num1, Value.MULTIPLY);
                    break;
                case DIVIDE:
                    answer = calculatorFraction(answer, num1, Value.DIVIDE);
                    break;
                default:
            }

            i = i + 2;
        }
        return answer;
    }

/**
*@Params: [a, b, v]
*@Return: com.android.arithmeticexcercise.FractionWrapper
*@Author: Likailing
*@Date: 2021/9/28 22:45
*@Desciption: 对两个分数进行计算
*/
    private FractionWrapper calculatorFraction(FractionWrapper a, FractionWrapper b, Value v) {

        int newSon = 0;
        int newMother = 0;
        FractionWrapper result;

        switch (v) {

            case ADD:
                newMother = a.mother * b.mother;
                newSon = a.son * b.mother + b.son * a.mother;
                break;
            case MINUS:
                newMother = a.mother * b.mother;
                newSon = a.son * b.mother - b.son * a.mother;
                break;
            case MULTIPLY:
                newMother = a.mother * b.mother;
                newSon = a.son * b.son;
                break;
            case DIVIDE:
                newMother = a.mother * b.son;
                newSon = a.son * b.mother;
                if (newMother == 0) {
                    System.out.println("ERROR # DIV/0");
                    return null;
                }
                break;
            default:

        }

        result = simplifyFraction(new FractionWrapper(newSon, newMother));

        return result;
    }
/**
*@Params: [fra]
*@Return: com.android.arithmeticexcercise.FractionWrapper
*@Author: Likailing
*@Date: 2021/9/28 22:46
*@Desciption: 对分数进行化简
*/
    private FractionWrapper simplifyFraction(FractionWrapper fra) {
        boolean judge = true;
        int temp1 = fra.son;
        int temp2 = fra.mother;

        if (temp1 < 0 && temp2 < 0) {
            temp1 *= -1;
            temp2 *= -1;
        } else if (temp1 < 0 && temp2 >0) {
            temp1 *= -1;
            judge = false;
        } else if (temp2 < 0 && temp1 >0) {
            temp2 *= -1;
            judge = false;
        }
        //查找最小公约数并化简
        while (true) {
            //当分子为分数时，就不用判断了
            if(temp1 == 0){
                fra.son=0;
                fra.mother=1;
                break;
            }

            if (temp1 >= temp2) {
                if (temp1 % temp2 == 0) {
                    fra = new FractionWrapper(fra.son / temp2, fra.mother / temp2);
                    if (fra.mother == 1) {
                        fra = new FractionWrapper(fra.son);
                    }
                    break;
                }
                if (temp1 % temp2 != 0) {
                    temp1 = temp1 % temp2;
                    continue;
                }
            }

            if (temp1 < temp2) {
                if (temp2 % temp1 == 0) {
                    fra = new FractionWrapper(fra.son / temp1, fra.mother / temp1);
                    if (fra.mother == 1) {
                        fra = new FractionWrapper(fra.son);
                    }
                    break;
                }
                if (temp2 % temp1 != 0) {
                    temp2 = temp2 % temp1;
                    continue;
                }
            }
        }
        if (judge = false) {
            fra.son *= -1;
            return fra;
        } else {
            return fra;
        }
    }


}
