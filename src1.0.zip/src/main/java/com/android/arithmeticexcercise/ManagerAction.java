package com.android.arithmeticexcercise;

import android.app.Application;
import android.content.ContentResolver;
import android.net.Uri;
import android.os.Build;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;

import java.io.File;
import java.io.InputStream;
import java.util.List;




/**
  *Date 2021/9/28 22:29
  *@ClassName: ManagerAction
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 用于响应安卓界面操作并执行相应功能
  */
public class ManagerAction {
    static String folderPath;
    static TextView textView;
    static List<ExpressionWrapper> expList;


    /**
     * @Return: void
     * @Author: Likailing
     * @Date: 2021/9/28 22:15
     * @Desciption:传入指定参数生成对应题目集
     */
    public static void generateExpressions(ArgWrapper arg) {
        GeneratorService generatorService = new GeneratorService();
        generatorService.generate(arg);
        expList = generatorService.getList();
    }


    /**
     * @Return: void
     * @Author: Likailing
     * @Date: 2021/9/28 22:15
     * @Desciption:将生成的题目集以及答案保存到对应文件
     */
    public static void printExpressionAndAnswer(String url) {
        PrinterDao printerDao = new PrinterDao();
        if (printerDao.printTo(url, expList)) {
            Toast.makeText(MyApplication.context, "题目保存成功", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(MyApplication.context, "题目保存失败,请检查文件设置是否正确", Toast.LENGTH_SHORT).show();
        }

    }

    /**
     * @Return: void
     * @Author: Likailing
     * @Date: 2021/9/28 22:16
     * @Desciption:批改文件并保存结果
     */
    @RequiresApi(api = Build.VERSION_CODES.Q)
    public static void checkFilesAndPrint(Uri exeUri, Uri ansUri) {
            File exeFile = UriAdapter.uriToFileApiQ(exeUri, MyApplication.context);
            File ansFile = UriAdapter.uriToFileApiQ(ansUri, MyApplication.context);
            System.out.println(exeFile.getName() + ansFile.getName());
            ViewerDao viewerDao = new ViewerDao();
            CheckerService checkerService = new CheckerService();
            checkerService.parsrFile(viewerDao.getText(exeFile), viewerDao.getText(ansFile));
            PrinterDao printerDao = new PrinterDao();
            if (printerDao.printTo(folderPath, checkerService.getCheckInfo())) {
                Toast.makeText(MyApplication.context, "文件保存成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MyApplication.context, "文件保存失败", Toast.LENGTH_SHORT).show();
            }


    }





     /**
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 22:17
     *@Desciption:将指定文件显示在界面
     */

     public static void previewFiles(int file){/*1:题目 2：答案 3：检查*/
          ViewerDao viewerDao =new ViewerDao();
          String text="";
          switch(file){
               case 1:
                    text= viewerDao.getText(folderPath+File.separator+"Exercises.txt");
                    break;
               case 2:
                    text= viewerDao.getText(folderPath+File.separator+"Answers.txt");
                    break;
               case 3:
                    text= viewerDao.getText(folderPath+File.separator+"Grade.txt");
                    break;
               default:
                    break;
          }
          if(text!=""){
               textView.setText(text);
          }else{
               textView.setText("没有找到文件");
          }
     }
     /**
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 22:17
     *@Desciption:将批改结果显示在批改界面
     */
     public static void previewCheckFile(TextView textView){
          ViewerDao viewerDao =new ViewerDao();
          String text="";
          text= viewerDao.getText(folderPath+File.separator+"Grade.txt");
          if(text!=""){
               textView.setText(text);
          }else{
               textView.setText("没有找到文件");
          }
     }


     /**
     *@param file 1:Exercise.txt 2:Answers.txt 3:Grade.txt
     *@Return: void
     *@Author: Likailing
     *@Date: 2021/9/28 22:18
     *@Desciption: 唤起打印面板并打印指定文件
     */
     public static void callPrinter(int file){
          String path=null;
          PrinterDao printerDao =new PrinterDao();
          switch(file){
               case 1:
                    path=folderPath+File.separator+"Exercises.txt";
                    printerDao.sendToPrinter(path,1);
                    break;
               case 2:
                    path=folderPath+File.separator+"Answers.txt";
                    printerDao.sendToPrinter(path,2);
                    break;
               case 3:
                    path=folderPath+File.separator+"Grade.txt";
                    printerDao.sendToPrinter(path,3);
                    break;
               default:
                    break;
          }


     }
}
