package com.android.arithmeticexcercise;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


/**
  *Date 2021/9/28 22:33
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 批改界面类
  */
public class CheckFragment extends Fragment {
    /**
     * the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
     */
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public static final int READ_QUEST_CODE = 42;
    public static final int READ_ANSWER_CODE=43;
    /**
     * 文件的uri对象
     */
    public static Uri file_exercise=null;
    public static Uri file_answer=null;
    /**
     * 按钮对象
     */
    Button buttonQuest;
    Button buttonAnswer;
    Button buttonCheck;
    /**
     * view组件
     */
    View view;

    private String mParam1;
    private String mParam2;

    public CheckFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CheckFragment.
     */
    public static CheckFragment newInstance(String param1, String param2) {
        CheckFragment fragment = new CheckFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:14
    *@Desciption: Fragment被创建时调用
    */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    /**
    *@Params: [inflater, container, savedInstanceState]
    *@Return: android.view.View
    *@Author: Likailing
    *@Date: 2021/9/28 23:15
    *@Desciption: View元件被创建时调用
    */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //注意作用域
        view=inflater.inflate(R.layout.fragment_check,null);

        return view;
    }
    /**
    *@Params: [view, savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:15
    *@Desciption: 在CreateView之后调用
    */
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        this.view=view;

    }
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:16
    *@Desciption: 在Activity被创建时调用
    */
    @RequiresApi(api = Build.VERSION_CODES.Q)
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        buttonQuest =view.findViewById(R.id.button_quest);
        buttonAnswer =view.findViewById(R.id.button_answer);
        buttonCheck =view.findViewById(R.id.button_check);
        TextView viewCheck =view.findViewById(R.id.textView_check);


        buttonQuest.setOnClickListener((View v)->{
            performFileSearch(1);
            //TODO
        });

        buttonAnswer.setOnClickListener((View v)->{
            performFileSearch(2);
            //TODO
        });

        buttonCheck.setOnClickListener((View v)->{
            if(file_answer!=null&&file_exercise!=null){
                String exeName=file_exercise.getPath().substring(file_exercise.getPath().lastIndexOf("/")+1,file_exercise.getPath().length());
                String ansName=file_answer.getPath().substring(file_answer.getPath().lastIndexOf("/")+1,file_answer.getPath().length());
                if("Exercises.txt".equals(exeName)&& "Answers.txt".equals(ansName)) {
                    ManagerAction.checkFilesAndPrint(file_exercise, file_answer);
                    ManagerAction.previewCheckFile(viewCheck);
                }else{
                    Toast.makeText(MyApplication.context,"加载的文件不合法",Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(getActivity(),"您有文件未加载",Toast.LENGTH_SHORT).show();
            }

        });



    }

/**
*@Params: [whichFile]
*@Return: void
*@Author: Likailing
*@Date: 2021/9/28 22:48
*@Desciption: 唤起文件管理器并选择需要批改的文件
*/
    public void performFileSearch(int whichFile) {//1 for exercise,2 for answer

        // ACTION_OPEN_DOCUMENT is the intent to choose a file via the system's file
        // browser.
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);

        // Filter to only show results that can be "opened", such as a
        // file (as opposed to a list of contacts or timezones)
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        // Filter to show only images, using the image MIME data type.
        // If one wanted to search for ogg vorbis files, the type would be "audio/ogg".
        // To search for all documents available via installed storage providers,
        // it would be "*/*".
        intent.setType("text/plain");
        switch (whichFile){
            case 1:
                getActivity().startActivityForResult(intent, READ_QUEST_CODE);
                break;
            case 2:
                getActivity().startActivityForResult(intent, READ_ANSWER_CODE);
                break;
            default:
                break;
        }

    }

}