package com.android.arithmeticexcercise;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
/**
  *Date 2021/9/28 22:36
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 用于快速获取context对象的应用类
  */
public class MyApplication extends Application {
    @SuppressLint("StaticFieldLeak")
    /**
     * 静态context
     */
    static Context context;

    /**
    *@Params: []
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:20
    *@Desciption: 用于获取Context
    */
    @Override
    public void onCreate() {
        super.onCreate();
        context=getApplicationContext();
    }
}
