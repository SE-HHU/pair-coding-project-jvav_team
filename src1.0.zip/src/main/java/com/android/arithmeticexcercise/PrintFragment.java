package com.android.arithmeticexcercise;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;

/**
  *Date 2021/9/28 22:37
  *@Author: Likailing
  *@Version: 1.0
  *@Desciption: 打印界面类
  */
public class PrintFragment extends Fragment {

    /**
     * the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
     */
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    View view;
    private String mParam1;
    private String mParam2;

    public PrintFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PrintFragment.
     */
    public static PrintFragment newInstance(String param1, String param2) {
        PrintFragment fragment = new PrintFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:21
    *@Desciption: Fragment被创建时调用
    */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    /**
    *@Params: [inflater, container, savedInstanceState]
    *@Return: android.view.View
    *@Author: Likailing
    *@Date: 2021/9/28 23:21
    *@Desciption: view元件被加载时调用
    */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view=inflater.inflate(R.layout.fragment_print,null);
        // Inflate the layout for this fragment
        return view;
    }
    /**
    *@Params: [savedInstanceState]
    *@Return: void
    *@Author: Likailing
    *@Date: 2021/9/28 23:21
    *@Desciption: Activity被创建时调用
    */
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        CheckBox checkBoxQuest=view.findViewById(R.id.checkBox_quest);
        CheckBox checkBoxAnswer=view.findViewById(R.id.checkBox_answer);
        CheckBox checkBoxGrade=view.findViewById(R.id.checkBox_grade);
        Button buttonPrint=view.findViewById(R.id.button_print);

        buttonPrint.setOnClickListener((View v)->{
            Boolean[] checkList=new Boolean[3];
            checkList[0]=checkBoxQuest.isChecked();
            checkList[1]=checkBoxAnswer.isChecked();
            checkList[2]=checkBoxGrade.isChecked();
            for(int i=0;i<3;i++){
                if(checkList[i]){
                    ManagerAction.callPrinter(i+1);
                }
            }

        });
    }


}